export class Book {
    id:number;
    title:string;
    year:string;
    author:string;
}