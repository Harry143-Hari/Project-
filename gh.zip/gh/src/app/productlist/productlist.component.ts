import { Component, OnInit } from '@angular/core';
//import products from 'src/app/exam/products.json'
import { ProductService } from 'src/app/product.service';


@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
 
  styleUrls: ['./productlist.component.css']
})

export class ProductlistComponent implements OnInit {
 // product=products
  constructor(private productservice :ProductService) { }

  ngOnInit() {
   //this.productservice.getProducts().subscribe((data)=>this.product=data,(error)=>console.log(error));;
  }
  //
}