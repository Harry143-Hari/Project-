import { Component, OnInit } from '@angular/core';
//import products from '../exam/products.json'
import { ProductService } from 'src/app/product.service';

@Component({
  selector: 'app-searchlist',
  templateUrl: './searchlist.component.html',
  styleUrls: ['./searchlist.component.css']
})

export class SearchlistComponent implements OnInit {
 
  resultProduct= products;
  

  constructor(private productservice:ProductService) { }

  ngOnInit() {
    this.productservice.getProducts().subscribe((data)=>this.resultProduct=data,(error)=>console.log(error));
  }


update(i) {
  this.resultProduct.push(i)
 }

delete(i) {
   this.resultProduct.splice(i, 1)
 }

 
 addnew(form){
  this.resultProduct.push(form)
}



}




