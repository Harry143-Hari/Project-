import { Injectable } from '@angular/core';
import products from '../app/exam/products.json'
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class ProductService {
  [x: string]: any;
  product=products
  value:string;

  constructor(private http:HttpClient) {}
  getProducts():Observable<products>{
    return  this.http.get<products>("../app/exam/products.json");
  }
}