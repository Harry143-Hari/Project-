import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ProductForm';

  model: any = {};

addProduct(productForm) {
  console.log(productForm.id+" "+productForm.name+" "+productForm.cost+" "+productForm.productOnline+" "+productForm.category+" "+productForm.gender+" "+productForm.store+" "+productForm.cb);
}

}

