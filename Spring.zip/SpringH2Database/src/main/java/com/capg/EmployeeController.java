package com.capg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class EmployeeController {

	@Autowired
	EmployeeRepo repo;
	
	
	@RequestMapping("/")
	public String form() {
		
		return "form";
	}
	
	@GetMapping("/display")
	public String display(EEEE emp, Model model) {
		
		model.addAttribute("emp",emp);
		
		
		repo.save(emp);
		
		
		return "display";
		
		
	}
	
	
}
