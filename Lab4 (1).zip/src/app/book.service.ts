import { Injectable } from '@angular/core';
import { Observable } from '../../node_modules/rxjs';
import { HttpClient } from '../../node_modules/@angular/common/http';
import { Book } from '../book';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  constructor(private http:HttpClient) { }

  file="/assets/booklist.json";

  getData():Observable<Book[]> {
    return this.http.get<Book[]>(this.file)
  }
}
