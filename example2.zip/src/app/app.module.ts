import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

// import {HttpClientModule,HttpClient} from '@angular/common/http';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import { ListallemployeeComponent } from './listallemployee/listallemployee.component';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeService } from './employee.service';

const routes: Routes = [
  {path: 'addemployee', component: AddemployeeComponent},
  {path: 'listallemployee', component: ListallemployeeComponent}

];

@NgModule({
  declarations: [
    AppComponent,
    AddemployeeComponent,
    ListallemployeeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    // HttpClientModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
