import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: 'mydir'
})
export class ChangeTextDirective {

  constructor(private ele: ElementRef) {
ele.nativeElement.innerText = 'Hello Text is Changed ';

   }

}
