import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.component.html',
  styleUrls: ['./directives.component.css']
})
export class DirectivesComponent implements OnInit {
choice = 0;
  isValid = true;
  jsonvar = {eid: '101', ename: 'Harish', sal: '100000000000'}


  name = 'Harish';
  cities = ['Delhi', 'Hyderabad', 'Andhra', 'Chennai'];
  constructor() { }

  ngOnInit() {
  }

}
