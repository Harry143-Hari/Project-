import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor() { }


student = {"sid":"101","sname":"Harish","course":"Java"};




getStudent(){
  console.log("Hi this is Harish, Student Getter");
}

}
