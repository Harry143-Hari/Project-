import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
name = 'Harish';
  title = 'my-app';
  choc: string = 'assets/chocolates.jpg';
  city: string ='Chennai' ;
  parentValue: string ='Hai this is ParentValue';
  sayHello(){
    alert("Chocolates are Sweet");

  }
  getData(value){
    alert(value);
  }
}
