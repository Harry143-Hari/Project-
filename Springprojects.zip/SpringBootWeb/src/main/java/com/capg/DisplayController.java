package com.capg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class DisplayController {

	/*@Autowired
	Employee emp = new Employee();*/
	
	@RequestMapping("/")
	public String form() {
		
		return "form";
	}
	
	/*@RequestMapping("/display")
	public String display(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		
		int eid = Integer.parseInt(request.getParameter("eid"));
		String ename = request.getParameter("ename");
		double salary = Double.parseDouble(request.getParameter("salary"));
		
		
		emp.setEid(eid);
		emp.setEname(ename);
		emp.setSalary(salary);
		
		session.setAttribute("emp",emp);
		
		return "display";
	}*/
	
	/*@RequestMapping("/display")
	public String display(@RequestParam("eid") int eid, @RequestParam("ename")String ename,@RequestParam("salary") double salary, Model m) {
		
		emp.setEid(eid);
		emp.setEname(ename);
		emp.setSalary(salary);
		
		m.addAttribute("emp",emp);
		return "display";
	}*/
	
	@PostMapping("/display")
	public ModelAndView display(Employee emp) {
		
		ModelAndView mv = new ModelAndView();
		
		mv.addObject("emp",emp);
		mv.setViewName("display");
		
		return mv;
	}
	
}
