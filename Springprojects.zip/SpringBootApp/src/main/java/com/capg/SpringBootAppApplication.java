package com.capg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class SpringBootAppApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(SpringBootAppApplication.class, args);

		Employee emp = context.getBean(Employee.class);

		emp.setEid(101);
		emp.setEname("Harish");
		emp.setSalary(2000000);

		System.out.println(emp);
	}

}
