package com.capg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capg.bean.Employee;



@Repository
public interface EmployeeRepository extends JpaRepository<Employee,Integer> {
    
	
	
	@Query("From Employee where salary = ?1 order by ename")
	List<Employee> findBySalary(double salary);
	
	
	
	
	@Query("From Employee Where Salary Between 0 and 30000")
	List<Employee> findByRange();
	
}
