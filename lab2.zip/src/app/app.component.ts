import { Component } from '@angular/core';
import { Employee } from './employee';
import { EmployeeService } from './employee.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  uid: number ;
   uname: string;
   usalary: number ;
    udepartment: string;
  title = 'LabBook';

  service: EmployeeService = new EmployeeService();

  emparr: Employee[] = [];

  addemp(data) {
    this.emparr = this.service.addemployee(data);
  }

  updating(emp) {
    this.uid = emp.id;
    this.uname = emp.name;
    this.usalary = emp.salary;
    this.udepartment = emp.department;
  }

  updemp(updata) {
    this.service.update(updata);
  }

  delete(i) {
    this.service.delete(i);
  }

}
