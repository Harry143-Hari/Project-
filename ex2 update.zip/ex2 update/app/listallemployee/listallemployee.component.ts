import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-listallemployee',
  templateUrl: './listallemployee.component.html',
  styleUrls: ['./listallemployee.component.css']
})
export class ListallemployeeComponent implements OnInit {

  ser:EmployeeService=new EmployeeService();
  listarr:Employee[]=[];

  constructor() { }

  ngOnInit() {
    this.listarr=this.ser.listEmpService();
    alert("List of All Employees");
    //alert(this.listarr[0].id)
  }

  update(i) {
    this.ser.update(i);
  }

  delete(i) {
    alert("Confirm to Delete");
    this.ser.delete(i);
  }
}
