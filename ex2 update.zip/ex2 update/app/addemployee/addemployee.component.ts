import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from "../Employee";

@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent implements OnInit {

  add:EmployeeService=new EmployeeService();
  empList: Employee[];

  constructor() { }

  ngOnInit() {
  }


  addemp(empform) {
    this.add.addEmpService(empform);
  }

}
