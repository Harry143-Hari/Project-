import { Component, OnInit } from '@angular/core';

import { ExserviceService } from '../exservice.service';
import { Product } from '../product';

@Component({
 selector: 'app-product',
 templateUrl: './product.component.html',
 styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

 constructor(private _service: ExserviceService) { }
 ProductList: Product[] ;
 ngOnInit() {
 this.getAllProducts();
 }
 getAllProducts() {
 this._service.getAllProducts().subscribe(db => this.ProductList = db);
 }
 deleteProduct(i) {
 this.ProductList.splice(i, 1);
 }


}
