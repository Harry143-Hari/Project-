import { Injectable } from '@angular/core';
import { Observable } from '../../node_modules/rxjs';
import { HttpClient } from '@angular/common/http';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ExserviceService {

url = '/assets/data/db.json';
constructor(private _http: HttpClient) { }

getAllProducts(): Observable<Product[]> {

  return this._http.get<Product[]>(this.url);

}
}
