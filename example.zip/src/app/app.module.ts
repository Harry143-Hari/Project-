import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductComponent } from './product/product.component';
import { SearchComponent } from './search/search.component';
import {HttpClientModule, HttpClient} from '@angular/common/http';
import { ExserviceService } from './exservice.service';
import { RouterModule, Routes } from '../../node_modules/@angular/router';
import { FormsModule } from '@angular/forms';


const routes: Routes = [

  { path: '', redirectTo: 'search', pathMatch: 'full'},
  { path : 'search' , component : SearchComponent},
  { path : 'product' , component : ProductComponent},
 ];
@NgModule({
  declarations: [
    AppComponent,
    ProductComponent,
    SearchComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
    FormsModule
  ],
  providers: [ExserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
