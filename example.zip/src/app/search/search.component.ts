import { Component, OnInit } from '@angular/core';
import { ExserviceService } from '../exservice.service';
import { Product } from '../product';
@Component({
 selector: 'app-search',
 templateUrl: './search.component.html',
 styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

 constructor(private route: ExserviceService) {
 }
 SearchList: Product[];
 List: Product[] = [];

 ngOnInit() {
 this.getAllProductList();
 }
 getAllProductList() {
 this.route.getAllProducts().subscribe(db => this.SearchList = db);
 }

 searchForm(val) {
  let j = 0;
for (let i = 0; i < this.SearchList.length; i++) {
 if (this.SearchList[i].category === val.uname) {
  this.List[j] = this.SearchList[i];
  j++;

 }
}
}
}
