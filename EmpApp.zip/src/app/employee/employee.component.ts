import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  constructor(private _service: EmployeeService) { }
  empList: Employee[] ;
  ngOnInit() {

    this.getAllEmployees();


  }

getAllEmployees() {

  this._service.getAllEmployees().subscribe(data => this.empList = data);

}

deleteEmployee(i) {

  this.empList.splice(i, 1);
}


delete(deleteForm) {


    for (let i = 0; i < this.empList.length; i++) {

        if  (this.empList[i].eid === deleteForm.value.eid)
        {
            this.empList.splice(i, 1);

        }

    }


}

addEmployee(addForm) {


  this.empList.push(addForm.value);
}


updateEmployee(updateForm) {
  for (let i = 0 ; i < this.empList.length; i++) {
    if (this.empList[i].eid == updateForm.value.eid) {

      this.empList[i] = updateForm.value;

    }
     }


}

}
